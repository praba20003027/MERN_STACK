const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const Restaurantroutes = require("./routers/Restaurant");
const mongoose = require("mongoose");
const MONGO_URI="mongodb://localhost:27017/zomato_60"
mongoose.set('strictQuery', true);


//connect to mongoDB
mongoose.connect(MONGO_URI,() => {
    console.log("mongoDB connected");
  },
  (e) => console.log(e)
);


const PORT=9090;

//create express server
var app = express();

//add middleware before routes
app.use(bodyParser.json());
app.use(cors());

//middleware routes
app.use("/resturants", Restaurantroutes);

//listen to a port
app.listen(PORT, () => {
  console.log(`the app has started on port ${PORT}`);
});